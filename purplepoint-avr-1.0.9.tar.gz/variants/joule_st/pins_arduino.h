// Pins

#ifndef Pins_Arduino_h
#define Pins_Arduino_h

/*
|-----|----------+------+--------------------+
| Pin | Label    | Port | Description        |
|-----|----------+---------------------------+
| 0   | SPI_MOSI | PB3  | SPI MOSI           |
| 1   | SPI_MISO | PB4  | SPI MISO           |
| 2   | SPI_SCK  | PB5  | SPI SCK            |
| 3   | WIRE_SDA | PC4  | WIRE SDA           |
| 4   | WIRE_SCL | PC5  | WIRE SCL           |
| 5   | RX       | PD0  | RX                 |
| 6   | TX       | PD1  | TX                 |
| 7   | RFM_CS   | PD2  | RFM9x CS           |
| 8   | RFM_RST  | PD3  | RFM9x RST          |
| 9   | RFM_IRQ  | PD5  | RFM9x IRQ          |
| 10  | VSW_EN   | PD6  | VSW Enable         |
+-----+----------+------+--------------------+
*/

#include <avr/pgmspace.h>

#define NUM_DIGITAL_PINS  	11
#define NUM_ANALOG_INPUTS 	0

#define PIN_SPI_SS    	(-1)	
#define PIN_SPI_MOSI  	(0)
#define PIN_SPI_MISO  	(1)
#define PIN_SPI_SCK   	(2)
#define LED_BUILTIN		(2)		// PB5

#define PIN_WIRE_SDA    (3)
#define PIN_WIRE_SCL    (4)

#define PIN_RX			(5)		// PD0
#define PIN_TX			(6)		// PD1

#define PIN_RFM_CS		(7)		// PD2
#define PIN_RFM_RST		(8)		// PD3
#define PIN_RFM_IRQ		(9)		// PD5

#define PIN_VSW_EN		(10)	// PD6


#define PA 1
#define PB 2
#define PC 3
#define PD 4

static const uint8_t VSW_EN = PIN_VSW_EN;

static const uint8_t MOSI = PIN_SPI_MOSI;
static const uint8_t MISO = PIN_SPI_MISO;
static const uint8_t SCK  = PIN_SPI_SCK;

static const uint8_t SDA = PIN_WIRE_SDA;
static const uint8_t SCL = PIN_WIRE_SCL;

static const uint8_t RX = PIN_RX;
static const uint8_t TX = PIN_TX;

static const uint8_t RFM_CS = PIN_RFM_CS;
static const uint8_t RFM_RST = PIN_RFM_RST;
static const uint8_t RFM_IRQ = PIN_RFM_IRQ;

#define analogInputToDigitalPin(p)  (-1)

#define digitalPinToPCICR(p)    (((p) >= 0 && (p) <= 10) ? (&PCICR) : ((uint8_t *)0))
#define digitalPinToPCICRbit(p) (((p) <= 3) ? 0 : (((p) < 5) ? 1 : 2))
#define digitalPinToPCMSK(p)    (((p) <= 3) ? (&PCMSK0) : (((p) < 5) ? (&PCMSK1) : (((p) < 11) ? (&PCMSK2) : ((uint8_t *)0))))
#define digitalPinToPCMSKbit(p) (((p) <= 3) ? (p + 3) : ((((p) < 5) ? ((p) + 1) : ((p) <= 9) ? ((p) - 5) : ((p) - 4))))

#define digitalPinToInterrupt(p)  ((p) == 2 ? 0 : ((p) == 3 ? 1 : NOT_AN_INTERRUPT))

#ifdef ARDUINO_MAIN

// these arrays map port names (e.g. port B) to the
// appropriate addresses for various functions (e.g. reading
// and writing)
const uint16_t PROGMEM port_to_mode_PGM[] = {
	NOT_A_PORT,
	NOT_A_PORT,
	(uint16_t) &DDRB,
	(uint16_t) &DDRC,
	(uint16_t) &DDRD,
};

const uint16_t PROGMEM port_to_output_PGM[] = {
	NOT_A_PORT,
	NOT_A_PORT,
	(uint16_t) &PORTB,
	(uint16_t) &PORTC,
	(uint16_t) &PORTD,
};

const uint16_t PROGMEM port_to_input_PGM[] = {
	NOT_A_PORT,
	NOT_A_PORT,
	(uint16_t) &PINB,
	(uint16_t) &PINC,
	(uint16_t) &PIND,
};

const uint8_t PROGMEM digital_pin_to_port_PGM[] = {
	PB, 	// SPI_MOSI - PB3
	PB,		// SPI_MISO - PB4
	PB,		// SPI_SCK - PB5
	PC,		// WIRE_SDA - PC4
	PC,		// WIRE_SCL - PC5
	PD,		// RX - PD0
	PD,		// TX - PD1
	PD,		// RFM_CS - PD2
	PD,		// RFM_RST - PD3
	PD,		// RFM_IRQ - PD5
	PD,		// VSW_EN - PD6
};

const uint8_t PROGMEM digital_pin_to_bit_mask_PGM[] = {
	_BV(3), 	// SPI_MOSI - PB3
	_BV(4),		// SPI_MISO - PB4
	_BV(5),		// SPI_SCK - PB5
	_BV(4),		// WIRE_SDA - PC4
	_BV(5),		// WIRE_SCL - PC5
	_BV(0),		// RX - PD0
	_BV(1),		// TX - PD1
	_BV(2),		// RFM_CS - PD2
	_BV(3),		// RFM_RST - PD3
	_BV(5),		// RFM_IRQ - PD5
	_BV(6),		// VSW_EN - PD6 
};

const uint8_t PROGMEM digital_pin_to_timer_PGM[] = {
	TIMER2A, 		// 0 - PB3
	NOT_ON_TIMER,	// 1 - PB4
	NOT_ON_TIMER,	// 2 - PB5
	NOT_ON_TIMER,	// 3 - PC4
	NOT_ON_TIMER,	// 4 - PC5
	NOT_ON_TIMER,	// 5 - PD0
	NOT_ON_TIMER,	// 6 - PD1
	NOT_ON_TIMER,	// 7 - PD2
	TIMER2B,	    // 8 - PD3
	TIMER0B,		// 9 - PD5
	TIMER0A,	    // 10 - PD6
};

#endif /* ARDUINO_MAIN */

#define SERIAL_PORT_HARDWARE       Serial

#endif