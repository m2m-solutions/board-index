// Pins

#ifndef Pins_Arduino_h
#define Pins_Arduino_h

/*
|-----|----------+------+--------------------+
| Pin | Label    | Port | Description        |
|-----|----------+---------------------------+
| 0   | D0       | PB2  | Digital pin 0      |
| 1   | D1       | PB1  | Digital pin 1      |
| 2   | D2       | PB0  | Digital pin 2      |
| 3   | D3       | PD7  | Digital pin 3      |
| 4   | A0       | PC3  | Analog pin 0       |
| 5   | A1       | PC2  | Analog pin 1       |
| 6   | LED_ERR  | PD5  | Red LED            |
| 7   | LED_TX   | PC0  | Green LED          |
| 8   | LED_RX   | PC1  | Yellow LED         |
| 9   | VSW_EN   | PD4  | VSW Enable         |
| 10  | FL_CE    | PD6  | Flash Enable       |
| 11  | SPI_MOSI | PB3  | SPI MOSI           |
| 12  | SPI_MISO | PB4  | SPI MISO           |
| 13  | SPI_SCK  | PB5  | SPI SCK            |
| 14  | MIRA_TX  | PD0  | Mira TX            |
| 15  | MIRA_RX  | PD1  | Mira RX            |
| 16  | DBG_RX   | PD2  | Debug RX           |
| 17  | DBG_TX   | PD3  | Debug TX           |
| 18  | WIRE_SDA | PC4  | WIRE SDA           |
| 19  | WIRE_SCL | PC5  | WIRE SCL           |
| A2  | A2       | ADC7 | Analog pin 3       |
| A3  | A3       | ADC8 | Analog pin 4       |
+-----+----------+------+--------------------+
*/


#include <avr/pgmspace.h>

#define NUM_DIGITAL_PINS  	20
#define NUM_ANALOG_INPUTS 	4

#define LED_BUILTIN		(13)	// PB5
#define LED_ERR			(6)		// PD5
#define LED_TX			(7)		// PC0
#define LED_RX			(8)		// PC1	

#define PIN_VSW_EN		(9)
#define PIN_FL_CE		(10)

#define PIN_SPI_SS    	(10)
#define PIN_SPI_MOSI  	(11)
#define PIN_SPI_MISO  	(12)
#define PIN_SPI_SCK   	(13)

#define PIN_WIRE_SDA    (18)
#define PIN_WIRE_SCL    (19)

#define PIN_DBG_RX		(15)
#define PIN_DBG_TX		(17)

#define PA 1
#define PB 2
#define PC 3
#define PD 4

static const uint8_t SS = PIN_SPI_SS;			// PB2
static const uint8_t MOSI = PIN_SPI_MOSI;		// PB3
static const uint8_t MISO = PIN_SPI_MISO;		// PB4
static const uint8_t SCK  = PIN_SPI_SCK;		// PB5

static const uint8_t SDA = PIN_WIRE_SDA;
static const uint8_t SCL = PIN_WIRE_SCL;

static const uint8_t A0 = 4;		// PC3
static const uint8_t A1 = 5;		// PC2
static const uint8_t A2 = 20;		// ADC6
static const uint8_t A3 = 21;		// ADC7

#define analogInputToDigitalPin(p)  ((p < 2) ? (p) + 4 : (p < 4) ? (p) + 18) : -1)

#define digitalPinToPCICR(p)    (((p) >= 0 && (p) <= 21) ? (&PCICR) : ((uint8_t *)0))
#define digitalPinToPCICRbit(p) (((p) <= 7) ? 2 : (((p) <= 13) ? 0 : 1))
#define digitalPinToPCMSK(p)    (((p) <= 7) ? (&PCMSK2) : (((p) <= 13) ? (&PCMSK0) : (((p) <= 21) ? (&PCMSK1) : ((uint8_t *)0))))
#define digitalPinToPCMSKbit(p) (((p) <= 7) ? (p) : (((p) <= 13) ? ((p) - 8) : ((p) - 14)))

#define digitalPinToInterrupt(p)  ((p) == 2 ? 0 : ((p) == 3 ? 1 : NOT_AN_INTERRUPT))

#ifdef ARDUINO_MAIN

// these arrays map port names (e.g. port B) to the
// appropriate addresses for various functions (e.g. reading
// and writing)
const uint16_t PROGMEM port_to_mode_PGM[] = {
	NOT_A_PORT,
	NOT_A_PORT,
	(uint16_t) &DDRB,
	(uint16_t) &DDRC,
	(uint16_t) &DDRD,
};

const uint16_t PROGMEM port_to_output_PGM[] = {
	NOT_A_PORT,
	NOT_A_PORT,
	(uint16_t) &PORTB,
	(uint16_t) &PORTC,
	(uint16_t) &PORTD,
};

const uint16_t PROGMEM port_to_input_PGM[] = {
	NOT_A_PORT,
	NOT_A_PORT,
	(uint16_t) &PINB,
	(uint16_t) &PINC,
	(uint16_t) &PIND,
};

const uint8_t PROGMEM digital_pin_to_port_PGM[] = {
	PB, 	// 0 - PB2
	PB,		// 1 - PB1
	PB,		// 2 - PB0
	PD,		// 3 - PD7
	PC,		// A0 - PC3
	PC,		// A1 - PC2
	PD,		// LED_ERR - PD5
	PC,		// LED_TX - PC0
	PC,		// LED_RX - PC1
	PD,		// VSW_EN - PD4
	PD,		// FL_CE - PD6
	PB,		// SPI_MOSI - PB3
	PB,		// SPI_MISO - PB4
	PB,		// SPI_SCK - PB5
	PD,		// MIRA_TX - PD0
	PD,		// Mira_RX - PD1
	PD,		// DBG_TX - PD2
	PD,		// DBG_RX - PD3
	PC,		// WIRE_SDA - PC4
	PC,		// WIRE_SCL - PC5
};

const uint8_t PROGMEM digital_pin_to_bit_mask_PGM[] = {
	_BV(2), 	// 0 - PB2
	_BV(1),		// 1 - PB1
	_BV(0),		// 2 - PB0
	_BV(7),		// 3 - PD7
	_BV(3),		// A0 - PC3
	_BV(2),		// A1 - PC2
	_BV(5),		// LED_ERR - PD5
	_BV(0),		// LED_TX - PC0
	_BV(1),		// LED_RX - PC1
	_BV(4),		// VSW_EN - PD4
	_BV(6),		// FL_CE - PD6
	_BV(3),		// SPI_MOSI - PB3
	_BV(4),		// SPI_MISO - PB4 
	_BV(5),		// SPI_SCK - PB5
	_BV(0),		// MIRA_TX - PD0
	_BV(1),		// MIRA_RX - PD1
	_BV(2),		// DBG_TX - PD2
	_BV(3),		// DBG_RX - PD3
	_BV(4),		// WIRE_SDA - PC4
	_BV(5),		// WIRE_SCL - PC5
};

const uint8_t PROGMEM digital_pin_to_timer_PGM[] = {
	TIMER1B, 		// 0 - PB2
	TIMER1A,		// 1 - PB1
	NOT_ON_TIMER,	// 2 - PB0
	NOT_ON_TIMER,	// 3 - PD7
	NOT_ON_TIMER,	// A0 - PC3
	NOT_ON_TIMER,	// A1 - PC2
	TIMER0B,		// LED_ERR - PD5
	NOT_ON_TIMER,	// LED_TX - PC0
	NOT_ON_TIMER,	// LED_RX - PC1
	NOT_ON_TIMER,	// VSW_EN - PD4
	TIMER0A,		// FL_CE - PD6
	TIMER2A,		// SPI_MOSI - PB3
	NOT_ON_TIMER,	// SPI_MISO - PB4
	NOT_ON_TIMER,	// SPI_SCK - PB5
	NOT_ON_TIMER,	// MIRA_TX - PD0
	NOT_ON_TIMER,	// MIRA_RX - PD1
	NOT_ON_TIMER,	// DBG_TX - PD2
	TIMER2B,		// DBG_RX - PD3
	NOT_ON_TIMER,	// WIRE_SDA - PC4
	NOT_ON_TIMER,	// WIRE_SCL - PC5
};
#endif /* ARDUINO_MAIN */

#define SERIAL_PORT_HARDWARE       Serial

#endif