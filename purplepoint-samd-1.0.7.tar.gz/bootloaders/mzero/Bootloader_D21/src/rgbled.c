/*
 * rgbled.c
 *
 * Created: 2018-07-08 19:58:55
 *  Author: jonny
 */ 
#include "rgbled.h"

void rgb_led_init(void)
{
	struct port_config pin_conf;
	port_get_config_defaults(&pin_conf);
	pin_conf.direction  = PORT_PIN_DIR_OUTPUT;
	port_pin_set_config(PIN_PB03, &pin_conf);
	port_pin_set_output_level(PIN_PB03, true);	
}

void rgb_led_set(uint8_t red, uint8_t green, uint8_t blue, uint8_t intensity)
{
    uint32_t bitMask = 0x800000;
	
    //volatile uint32_t* set = &(PORT->Group[portNum].OUTSET.reg);
    //volatile uint32_t* clr = &(PORT->Group[portNum].OUTCLR.reg);

	PortGroup *const port_base = port_get_group_from_gpio_pin(PIN_PB03);
	uint32_t pin_mask  = (1UL << (PIN_PB03 % 32));

	/* Set the pin to high or low atomically based on the requested level */
	//volatile uint32_t* set = port_base->OUTSET.reg = pin_mask;
	//volatile uint32_t* clr = port_base->OUTCLR.reg = pin_mask;

    // Neopixels is ordered GRB
    uint32_t rgbValue = (green * intensity / 100) << 16;
    rgbValue |= (red * intensity / 100) << 8;
    rgbValue |= (blue * intensity / 100);

    for(int i = 0; i < 24; i++) {
	    //*set = pin_mask;
		port_base->OUTSET.reg = pin_mask;
	    asm("nop; nop; nop; nop; nop; nop; nop; nop;");
	    if(rgbValue & bitMask) {
		    asm("nop; nop; nop; nop; nop; nop; nop; nop;"
		    "nop; nop; nop; nop; nop; nop; nop; nop;"
		    "nop; nop; nop; nop;");			
		    //*clr = pin_mask;
			port_base->OUTCLR.reg = pin_mask;
		    } else {
		    //*clr = pin_mask;
			port_base->OUTCLR.reg = pin_mask;
		    asm("nop; nop; nop; nop; nop; nop; nop; nop;"
		    "nop; nop; nop; nop; nop; nop; nop; nop;"
		    "nop; nop; nop; nop;");
	    }
	    if(bitMask >>= 1) {
		    asm("nop; nop; nop; nop; nop; nop; nop; nop; nop;");
	    }
    }
}