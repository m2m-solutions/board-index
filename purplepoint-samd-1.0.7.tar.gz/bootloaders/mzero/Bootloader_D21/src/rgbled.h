/*
 * rgbled.h
 *
 * Created: 2018-07-08 14:47:07
 *  Author: jonny
 */ 


#ifndef RGBLED_H_
#define RGBLED_H_

#include "compiler.h"
#include "port.h"

void rgb_led_init(void);
void rgb_led_set(uint8_t red, uint8_t green, uint8_t blue, uint8_t intensity);

#endif /* RGBLED_H_ */