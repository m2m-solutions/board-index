# M2M_TLV
Arduino library for packing and unpacking data in TLV format.

Written by Mathias Korall for M2M Solutions AB.

# License

Copyright (c) 2017-2018, M2M Solutions AB. All rights reserved.

This library is open source. It is released under the [MIT License](LICENSE.txt). 
Please see the included LICENSE.txt file for more information.
